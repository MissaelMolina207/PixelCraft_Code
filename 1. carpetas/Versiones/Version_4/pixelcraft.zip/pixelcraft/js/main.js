import { $, getJSON, wa, toast } from './utils.js';
import { store } from './store.js';
import { initCatalog } from './catalog.js';
import { initCart } from './cart.js';
import { initStudio } from './studio.js';
import { initLead } from './lead.js';

try {
  [store.site, store.products] = await Promise.all([getJSON('data/site.json'), getJSON('data/products.json')]);
} catch {
  document.body.insertAdjacentHTML('afterbegin', '<p style="padding:90px 20px">No cargaron los datos. Abre el sitio con un servidor (npm run static), no con doble clic.</p>');
  throw new Error('data');
}

const { whatsapp, slots } = store.site;
$('#waMain').href = $('#waDock').href = wa(whatsapp, 'Hola PixelCraft, quiero cotizar un proyecto.');
$('#slotsTxt').textContent = `${slots.total - slots.used} de ${slots.total} disponibles`;
$('#slotsBar').style.width = slots.used / slots.total * 100 + '%';
$('#play').onclick = () => toast('Aquí va tu <video>: assets/showreel.mp4 con preload="none".');

initCart(); initCatalog(); initStudio(); initLead();
