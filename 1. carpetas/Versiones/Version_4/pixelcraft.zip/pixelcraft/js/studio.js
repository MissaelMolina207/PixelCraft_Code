import { $, toast, wa, post } from './utils.js';
import { store } from './store.js';
import { addItem, openCart } from './cart.js';

// S.mode = cómo se hizo el arte actual (a: texto, b: fusión). Las pestañas solo cambian el panel.
const S = { mode: 'a', prod: 'shirt', art: null, refs: [], prompt: '' };
const PN = { shirt: 'Playera', plate: 'Placa o letrero' };
const SHIRT = new Path2D('M150 70 L100 95 L45 150 L85 190 L120 165 L120 400 L360 400 L360 165 L395 190 L435 150 L380 95 L330 70 C310 100 270 112 240 112 C210 112 170 100 150 70Z');
let cv, cx;

function mock() {
  cx.fillStyle = '#15161a'; cx.fillRect(0, 0, 480, 480);
  cx.fillStyle = '#2b2d34'; cx.strokeStyle = 'rgba(247,248,251,.18)'; cx.lineWidth = 2;
  if (S.prod === 'shirt') { cx.fill(SHIRT); cx.stroke(SHIRT); if (S.art) cx.drawImage(S.art, 170, 150, 140, 140); }
  else { cx.beginPath(); cx.roundRect(60, 130, 360, 220, 10); cx.fill(); cx.stroke(); if (S.art) cx.drawImage(S.art, 150, 150, 180, 180); }
  if (!S.art) { cx.fillStyle = 'rgba(247,248,251,.45)'; cx.font = '600 15px system-ui'; cx.textAlign = 'center'; cx.fillText('Tu diseño aparecerá aquí', 240, 448); }
  ['#buy', '#wa'].forEach(s => $(s).classList.toggle('off', !S.art));
  // TODO: subir el mockup vía n8n a storage y poner la URL pública en S.url (wa.me no adjunta imágenes)
  const msg = `Hola PixelCraft, quiero cotizar una idea.\nProducto: ${PN[S.prod]}\nModo: ${S.mode === 'a' ? 'texto a imagen' : 'fusión de ' + S.refs.length + ' referencias'}\n`
    + (S.prompt ? `Prompt: "${S.prompt}"\n` : '') + `Mockup: ${S.url || '(lo adjunto en este chat)'}`;
  $('#wa').href = S.art ? wa(store.site.whatsapp, msg) : '#';
}

/* ---- Generación: /api/generate (Replicate). Sin API → modo simulado local. ---- */
const rng = a => () => { a |= 0; a = a + 0x6D2B79F5 | 0; let t = Math.imul(a ^ a >>> 15, 1 | a); t = t + Math.imul(t ^ t >>> 7, 61 | t) ^ t; return ((t ^ t >>> 14) >>> 0) / 4294967296; };
const hash = s => [...s].reduce((h, c) => Math.imul(h ^ c.charCodeAt(0), 16777619) >>> 0, 2166136261);
function fakeIA(prompt) {
  const c = document.createElement('canvas'); c.width = c.height = 512;
  const g = c.getContext('2d'), r = rng(hash(prompt)), pal = ['#cd0000', '#ff0000', '#f7f8fb', '#580000'];
  for (let i = 0; i < 14; i++) {
    g.strokeStyle = g.fillStyle = pal[(r() * 4) | 0]; g.globalAlpha = .35 + r() * .6; g.lineWidth = 2 + r() * 10;
    const x = r() * 512, y = r() * 512, s = 30 + r() * 170; g.beginPath();
    if (r() > .5) g.arc(x, y, s, 0, 7); else { g.moveTo(x, y); g.lineTo(x + (r() - .5) * 400, y + (r() - .5) * 400); }
    r() > .5 ? g.fill() : g.stroke();
  }
  return c;
}
const toImage = src => new Promise((ok, no) => { const i = new Image(); i.onload = () => ok(i); i.onerror = no; i.src = src; });
async function generate(prompt) {
  try { return await toImage((await post('/api/generate', { prompt })).image); }
  catch (e) { if (![undefined, 404, 501].includes(e.status)) throw e; return fakeIA(prompt); }
}

/* ---- Fusión de referencias (canvas, 100% cliente) ---- */
const readFile = f => new Promise(ok => { const r = new FileReader(); r.onload = () => toImage(r.result).then(ok); r.readAsDataURL(f); });
async function addFiles(fl) {
  const imgs = [...fl].filter(f => f.type.startsWith('image/'));
  S.refs = S.refs.concat(await Promise.all(imgs.map(readFile)));
  $('#refs').innerHTML = S.refs.map(i => `<img src="${i.src}" alt="Referencia">`).join('');
}
const cover = (g, i) => { const k = Math.max(512 / i.width, 512 / i.height), w = i.width * k, h = i.height * k; g.drawImage(i, (512 - w) / 2, (512 - h) / 2, w, h); };

export function initStudio() {
  cv = $('#cv'); cx = cv.getContext('2d');
  const pick = (box, attr, fn) => $(box).onclick = e => {
    const b = e.target.closest('[' + attr + ']'); if (!b) return;
    [...$(box).children].forEach(x => x.setAttribute('aria-pressed', x === b));
    fn(b.getAttribute(attr));
  };
  pick('#mode', 'data-m', m => { $('#pa').hidden = m !== 'a'; $('#pb').hidden = m !== 'b'; });
  pick('#prod', 'data-p', p => { S.prod = p; mock(); });

  $('#gen').onclick = async () => {
    const p = $('#prompt').value.trim(), btn = $('#gen');
    if (p.length < 4) return toast('Escribe una idea. Una palabra no es un brief.');
    btn.disabled = true; btn.textContent = 'Generando…';
    try { S.art = await generate(p); S.mode = 'a'; S.prompt = p; mock(); }
    catch { toast('La IA se quedó sin ideas. Intenta de nuevo.'); }
    finally { btn.disabled = false; btn.textContent = 'Generar diseño'; }
  };

  const dz = $('#drop');
  $('#files').onchange = e => addFiles(e.target.files);
  ['dragenter', 'dragover'].forEach(v => dz.addEventListener(v, e => { e.preventDefault(); dz.classList.add('on'); }));
  ['dragleave', 'drop'].forEach(v => dz.addEventListener(v, e => { e.preventDefault(); dz.classList.remove('on'); }));
  dz.addEventListener('drop', e => addFiles(e.dataTransfer.files));
  $('#fuse').onclick = () => {
    if (S.refs.length < 2) return toast('Necesito 2 imágenes mínimo. Fusionar una sola se llama copiar.');
    const c = document.createElement('canvas'); c.width = c.height = 512;
    const g = c.getContext('2d'); cover(g, S.refs[0]);
    g.globalCompositeOperation = 'overlay'; g.globalAlpha = $('#mix').value / 100;
    S.refs.slice(1).forEach(i => cover(g, i));
    S.art = c; S.mode = 'b'; S.prompt = ''; mock(); toast('Fusión lista.');
  };

  $('#buy').onclick = () => {
    if (!S.art) return;
    const id = S.prod === 'shirt' ? 'ia-shirt' : 'ia-plate', p = store.products.find(x => x.id === id);
    addItem({ id, name: p.name, price: p.price, img: cv.toDataURL('image/jpeg', .6) });
    openCart();
  };
  mock();
}
