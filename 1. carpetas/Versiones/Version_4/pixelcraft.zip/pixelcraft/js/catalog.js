import { $, fmt, wa } from './utils.js';
import { store } from './store.js';
import { addItem } from './cart.js';

const CATS = { all: 'Todo', '3d': 'Impresión 3D', screen: 'Serigrafía', cut: 'Corte y volumen', promo: 'Promocionales' };
let cat = 'all', scrolled = false;

function render() {
  const q = $('#q').value.trim().toLowerCase();
  const list = store.products.filter(p => !p.hidden && (cat === 'all' || p.cat === cat) && p.name.toLowerCase().includes(q));
  $('#grid').innerHTML = list.length
    ? list.map(p => `<article class="card"><div class="thumb">${p.tag}</div><h3 style="font-size:1.05rem">${p.name}</h3><div class="price">${fmt(p.price)} <small>${p.unit}</small></div><div class="row"><button class="btn red" data-add="${p.id}">Comprar muestra</button><a class="btn" target="_blank" rel="noopener" href="${wa(store.site.whatsapp, 'Hola PixelCraft, quiero cotizar: ' + p.name)}">Cotizar</a></div></article>`).join('')
    : '<p>Nada con ese nombre. Prueba “playera” o escríbenos: fabricamos cosas raras.</p>';
}

export function initCatalog() {
  $('#chips').innerHTML = Object.entries(CATS).map(([k, v]) => `<button class="chip" data-c="${k}" aria-pressed="${k === cat}">${v}</button>`).join('');
  $('#chips').onclick = e => {
    const b = e.target.closest('[data-c]'); if (!b) return;
    cat = b.dataset.c;
    [...$('#chips').children].forEach(x => x.setAttribute('aria-pressed', x === b));
    render();
  };
  $('#grid').onclick = e => {
    const b = e.target.closest('[data-add]'); if (!b) return;
    const p = store.products.find(x => x.id === b.dataset.add);
    addItem({ id: p.id, name: p.name, price: p.price });
  };
  $('#q').oninput = () => { if (!scrolled) { $('#catalogo').scrollIntoView(); scrolled = true; } render(); };
  render();
}
